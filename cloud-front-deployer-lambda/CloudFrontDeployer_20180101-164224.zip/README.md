Kieschnick Consulting
---------------------

Deployment:
```npm run deploy```

ensure you have set aws credential env variables:

AWS_ACCESS_KEY_ID
AWS_SECRET_ACCESS_KEY